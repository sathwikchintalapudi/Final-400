# coronaTracker
Application to show static dashboart with corona stats arount the world using the details updated by WHO

Tech stack:
Java 8 
ThymeLeaf for presentation layer
Spring scheduler to update the WHO stats to application every 1 hr
Spring security

username and password to access application:

username : user
pwd : pswpsw123