package com.learning.coronatracker;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class CoronaTrackerApplicationTests {

	@Test
	public void contextLoads() {
	}

}
