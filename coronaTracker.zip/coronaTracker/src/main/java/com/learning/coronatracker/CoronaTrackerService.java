package com.learning.coronatracker;

import domain.RegionDetails;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVRecord;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.client.RestTemplate;

import javax.annotation.PostConstruct;
import java.io.StringReader;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

@Service
public class CoronaTrackerService {

    @PostConstruct
    public void initiateRun() {
        RestTemplate restTemplate = new RestTemplate();
        ResponseEntity<String> response
            = restTemplate.getForEntity("http://localhost:8083/sathwik", String.class);

        System.out.println(response.getStatusCode());
    }
}
